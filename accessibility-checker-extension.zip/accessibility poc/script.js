// JavaScript Function to Apply Accessibility CSS
document.getElementById('accessibility-button').addEventListener('click', function() {
    document.body.classList.toggle('high-contrast');
    document.body.classList.toggle('large-text');
    document.body.classList.toggle('focus-indicators');
    document.body.classList.toggle('increase-spacing');
});
