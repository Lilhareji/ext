 // Function to check for missing alt attributes on images
function checkImages() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        if (!img.hasAttribute('alt')) {
            img.classList.add('accessibility-issue');
            console.warn('Image missing alt attribute:', img);
        }
    });
}

// Function to check for missing labels on form elements
function checkForms() {
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        if (!document.querySelector(`label[for='${input.id}']`) && !input.closest('label')) {
            input.classList.add('accessibility-issue');
            console.warn('Form element missing label:', input);
        }
    });
}

// Function to check for low contrast text
function checkContrast() {
    const elements = document.querySelectorAll('*');
    elements.forEach(el => {
        const style = window.getComputedStyle(el);
        const color = style.color;
        const bgColor = style.backgroundColor;

        // Convert colors to RGB arrays
        const rgbColor = color.match(/\d+/g).map(Number);
        const rgbBgColor = bgColor.match(/\d+/g).map(Number);

        if (rgbColor.length === 3 && rgbBgColor.length === 3) {
            // Calculate contrast ratio (simplified)
            const brightnessColor = (rgbColor[0] * 299 + rgbColor[1] * 587 + rgbColor[2] * 114) / 1000;
            const brightnessBg = (rgbBgColor[0] * 299 + rgbBgColor[1] * 587 + rgbBgColor[2] * 114) / 1000;
            const contrastRatio = (Math.max(brightnessColor, brightnessBg) + 0.05) / (Math.min(brightnessColor, brightnessBg) + 0.05);

            if (contrastRatio < 4.5) { // WCAG AA standard for normal text
                el.classList.add('low-contrast');
                console.warn('Low contrast text:', el);
            }
        }
    });
}

 
console.log('Run PANKAJ checks');

    checkImages();
    checkForms();
    checkContrast();
	
	
// Run accessibility checks
/*document.addEventListener('DOMContentLoaded', () => {
	console.log('Run accessibility checks');
    checkImages();
    checkForms();
    checkContrast();
});
*//*
setTimeout(() => {
    console.log('Running checks after delay');
    checkImages();
    checkForms();
    checkContrast();
}, 1000);
*/