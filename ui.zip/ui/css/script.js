function spinImage() {
    const image = document.getElementById('spin-image');
    image.classList.toggle('spin');
}


function moveImage() {
    const image = document.getElementById('move-lc-image');
    image.classList.add('move');

    const imageRC = document.getElementById('move-rc-image');
    imageRC.classList.add('moveRC');

    const imageC = document.getElementById('move-mc-image');
    imageC.classList.add('moveMC');
    //window.setTimeout(10000);
   // window.location.href = 'index3-1.html';
}


document.addEventListener('DOMContentLoaded', () => {
    const animatedElement = document.querySelector('#move-rc-image');

    // Function to call when animation ends
    function onAnimationEnd() {
        console.log('Animation completed!');
        window.location.href = 'index3-1.html';
    }

    // Attach the event listener to the element
    animatedElement.addEventListener('animationend', onAnimationEnd);
});
